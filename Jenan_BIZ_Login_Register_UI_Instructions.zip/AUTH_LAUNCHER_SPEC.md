# AUTH LAUNCHER / BOTTOM ICON SPEC

الحالة المغلقة:
- أيقونة زجاجية صغيرة أسفل الشاشة
- cyan edge
- glow هادئ
- لا حركة مستمرة مزعجة

عند الضغط:
- تظهر لوحة صغيرة فوق الأيقونة
- تسجيل الدخول
- إنشاء حساب
- optional label: ابدأ مع جنان بيز
- لا تعرض fields هنا

الحركة:
- scale 0.96 -> 1
- opacity 0 -> 1
- 180–240ms

التنقل:
- Login -> /login
- Register -> /register
