# JENAN BIZ — STRICT LOGIN / REGISTER IMPLEMENTATION CONTRACT

## 1. المرجع
- `reference-approved-home.png` هو المرجع البصري الأعلى.
- لا تعيد التصميم من الصفر.
- لا تحول الواجهة إلى SaaS تقليدي أو Dashboard مسطح.

## 2. الهوية
- Deep Navy / Black Blue
- Electric Cyan
- Teal / Emerald
- Gold accents بحذر
- Glass depth
- Subtle glow
- World network + future city atmosphere

## 3. Desktop
- خلفية عالمية ديناميكية مستوحاة من المرجع.
- Auth workspace زجاجي Premium.
- لا يغطي معظم المشهد.
- Brand واضح.
- رسائل ثقة وأمان وقيمة.
- لا أرقام Production وهمية.

## 4. Mobile
- لا تصغّر Desktop كما هو.
- أعد تركيب العناصر حسب الأولوية.
- Auth card أولًا.
- لا horizontal overflow.

## 5. Login
- الشعار الرسمي
- مرحبًا بعودتك
- البريد الإلكتروني
- كلمة المرور
- إظهار/إخفاء كلمة المرور
- تذكرني
- استعادة الوصول
- زر تسجيل الدخول
- انتقال إلى إنشاء حساب
- حالات loading/error/success

## 6. Register
- الاسم الكامل
- البريد الإلكتروني
- رقم الجوال إذا كان مطلوبًا فعليًا
- كلمة المرور
- تأكيد كلمة المرور
- الشروط والأحكام
- زر إنشاء الحساب
- انتقال إلى تسجيل الدخول
- Progressive flow إذا زادت الحقول

## 7. Auth Launcher أسفل الشاشة
إذا استخدم التصميم أيقونة أسفل الشاشة:
- عند الضغط تظهر لوحة صغيرة بخيارين فقط:
  1. تسجيل الدخول
  2. إنشاء حساب
- لا تعرض الحقول داخل الـlauncher.
- الحركة 180–260ms ease-out.
- الخلفية تبقى ظاهرة.
- Escape يغلق على Desktop.
- Tap outside يغلق على Mobile.

## 8. منع التمدد
ممنوع:
- scaleX / scaleY
- object-fit: fill
- شد الشعار أو الخريطة أو المدينة أو البطاقات أو الأيقونات
- تكبير العناصر فقط لتعبئة الفراغ

مطلوب:
- max-width container
- backgrounds only extend
- object-fit: contain للعناصر الحساسة
- responsive grid/flex
- clamp() عند الحاجة

## 9. الأيقونات
- أسلوب واحد
- سماكة واحدة
- لا خلط عشوائي بين 3D / outline / filled
- أيقونات الدخول والحساب جزء من DNA جنان

## 10. الخطوط
- العربية أولوية
- English LTR مستقل
- hierarchy واضح
- لا خط افتراضي رخيص إذا يوجد خط معتمد

## 11. الحالات
صمّم:
- idle
- hover
- focus
- loading
- success
- error
- disabled
- rate-limited
- session expired

## 12. الحفاظ على الـCore
ممنوع تغيير:
- Auth logic
- Sessions
- RBAC
- Rate limiting
- Audit logging
- Password hashing
- Origin protection
- Database
إلا لعطل حقيقي وموافقة واضحة.

## 13. البيانات
أي أرقام في المرجع أمثلة بصرية فقط.
استخدم real data أو:
- بيانات تجريبية
- بانتظار المصدر
- غير متاح

## 14. Accessibility
- labels حقيقية
- focus visible
- keyboard navigation
- contrast قوي
- ARIA عند الحاجة
- لا تعتمد على اللون وحده للخطأ

## 15. المقاسات
اختبار إلزامي:
- 2560×1440
- 1920×1080
- 1661×947
- 1440×900
- 1280×800
- 820×1180
- 390×844

## 16. الاعتماد
لا تعتبر الواجهة جاهزة حتى:
- no stretch
- no overflow
- RTL/LTR صحيح
- no fake data
- login works
- register works
- screenshots مقارنة بالمرجع
- typecheck/lint/tests/build pass
