# AUTH UI QA CHECKLIST

## Visual
- [ ] نفس DNA الصفحة الرئيسية
- [ ] لا Stretch
- [ ] لا SaaS مسطح
- [ ] الخلفية العالمية حاضرة
- [ ] Auth card لا يغطي المشهد
- [ ] الأيقونات موحدة
- [ ] العربية مصقولة

## Functional
- [ ] Login works
- [ ] Register works
- [ ] Show/hide password works
- [ ] Forgot password route works if implemented
- [ ] Validation correct
- [ ] Loading/disabled correct
- [ ] Session redirect correct
- [ ] Protected routes unchanged

## Responsive
- [ ] 2560×1440
- [ ] 1920×1080
- [ ] 1661×947
- [ ] 1440×900
- [ ] 1280×800
- [ ] 820×1180
- [ ] 390×844
- [ ] No horizontal overflow

## Technical
- [ ] typecheck
- [ ] lint
- [ ] tests
- [ ] build
- [ ] screenshots
- [ ] visual comparison
