Jenan BIZ Home Visual Source Package

Open index.html to view the approved design exactly as supplied.

Files:
- reference-home.png : approved reference
- index.html : exact visual viewer without distortion
- tokens.css : extracted visual design tokens / no-stretch rules
- IMPLEMENTATION_SPEC.md : strict implementation contract
- component-map.json : component breakdown for React/CSS implementation

Important:
The exact PNG viewer is 100% visually identical because it renders the original image.
For a real production UI, treat the PNG as visual authority, not as a runtime background.
