# Jenan BIZ — Approved Home Visual Source of Truth

## Authority
`reference-home.png` is the approved visual authority for the Jenan BIZ homepage after login.

## What “100%” means
- `index.html` renders the approved reference image itself, therefore it is visually exact at the reference composition.
- A real React/CSS implementation can be made extremely close, but exact pixel parity cannot be guaranteed from a flattened raster image alone without the original source assets, fonts, vector icons, globe/city source layers, and exact typography files.
- Do NOT use the PNG itself as the production page background. It is a visual authority/reference only.

## Critical no-stretch rule
1. Never stretch the full composition to fill wider screens.
2. Never use `object-fit: fill` for the logo, globe, city, cards, icons, or charts.
3. Desktop content should sit inside a centered max-width container.
4. Extra-wide screens extend the atmosphere/background only.
5. Tablet/mobile must be recomposed by priority, not shrunk as a screenshot.

## Major visual zones
1. Global header / main navigation.
2. Hero statement block.
3. Central world-intelligence globe / city environment.
4. Global opportunity/growth indicators.
5. Feature/benefit icon row.
6. News & updates panel.
7. Platform statistics panel.
8. User distribution chart.
9. Trust/value strip.
10. Footer / legal / social links.

## Visual DNA
- Deep navy / black-blue foundation.
- Electric cyan as the primary light language.
- Teal/emerald for positive states.
- Gold and violet only as controlled accents.
- Strong depth, glass, edge light, subtle volumetric glow.
- Bright content hierarchy, not a flat dark dashboard.
- Each internal section should inherit this DNA while developing its own accent and hero logic.

## Data integrity
Any numbers visible in the approved image are visual examples only unless backed by a real source.
Production must show real values or an explicit “data unavailable / awaiting source / demo” state.

## Implementation acceptance
For each viewport capture a real browser screenshot and compare against the approved reference:
- 2560×1440
- 1920×1080
- 1661×947 (reference)
- 1440×900
- 1280×800
- 820×1180
- 390×844

Acceptance requires:
- no distortion
- no unintended overflow
- no flattened single-color treatment
- consistent icon family
- correct RTL/LTR
- clear states for live/demo/unavailable data
- no changes to Auth/DB/RBAC/API contracts during visual implementation
